#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────
# start-session.sh — МЕХАНИКА начала сессии (без Claude)
# Подтягивает бэкап с GitHub (если работал с другого устройства), обновляет конфиг Claude, проверяет среду.
# Контекст задач (трекер) добавляет скилл /start поверх этого.
#
# Использование:  start-session.sh   (или алиас `start`)
# Переопределяемо:  BRANCH, CLAUDE_CONFIG_DIR, EDITOR_SETTINGS, THEME_MARKER
# ─────────────────────────────────────────────────────────────
set -uo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BRANCH="${BRANCH:-main}"
CLAUDE_CONFIG_DIR="${CLAUDE_CONFIG_DIR:-$HOME/claude-config}"
EDITOR_SETTINGS="${EDITOR_SETTINGS:-$HOME/Library/Application Support/Code/User/settings.json}"
THEME_MARKER="${THEME_MARKER:-Dark Modern}"   # «канарейка»: настроена ли среда
SECRETS_FILE="${SECRETS_FILE:-$HOME/.claude-secrets}"
WARN=0

echo "🚀  НАЧАЛО СЕССИИ"
echo "────────────────────────────"

# ① Подтянуть бэкап (проекты)
echo "①  Подтягиваю бэкап проектов с GitHub…"
if "$ROOT/scripts/sync-start.sh" >/tmp/start-sync.log 2>&1; then
  tail -3 /tmp/start-sync.log | grep -E '[0-9a-f]{7}' | head -3 | sed 's/^/    /'
  echo "    ✓ проекты актуальны"
else
  echo "    ⚠ не удалось обновить — открой /tmp/start-sync.log"; WARN=1
fi

# ② Обновить конфиг Claude (skills + память) — при желании вынесен в отдельный репо
echo "②  Обновляю конфиг Claude…"
if [ -d "$CLAUDE_CONFIG_DIR/.git" ]; then
  git -C "$CLAUDE_CONFIG_DIR" pull --rebase --autostash -q 2>/dev/null \
    && echo "    ✓ skills/память актуальны" \
    || echo "    ⚠ claude-config не обновился"
else
  echo "    — claude-config не найден ($CLAUDE_CONFIG_DIR), пропуск"
fi

# ③ Настройки редактора (тема как маркер, что среда настроена)
echo "③  Настройки редактора…"
if [ -f "$EDITOR_SETTINGS" ] && grep -q "$THEME_MARKER" "$EDITOR_SETTINGS" 2>/dev/null; then
  echo "    ✓ эталонная тема на месте ($THEME_MARKER)"
else
  echo "    ⚠ настройки редактора не эталонные — запусти скилл vscode-setup"; WARN=1
fi

# ④ Секреты
echo "④  Секреты…"
if [ -f "$SECRETS_FILE" ]; then
  MK=$(grep -c '^[A-Za-z_][A-Za-z0-9_]*=' "$SECRETS_FILE" 2>/dev/null || echo 0)
  echo "    ✓ $MK ключей в $SECRETS_FILE"
else
  echo "    ⚠ нет $SECRETS_FILE — перенеси/введи секреты (см. set-secret.sh)"; WARN=1
fi

# ⑤ Синхронность с origin
echo "⑤  Синхронность…"
cd "$ROOT"; git fetch origin -q 2>/dev/null
if [ "$(git rev-parse HEAD 2>/dev/null)" = "$(git rev-parse origin/$BRANCH 2>/dev/null)" ]; then
  echo "    ✓ локально = origin ($(git rev-parse --short HEAD))"
else
  echo "    ⚠ локально отстало — выполни sync-start"; WARN=1
fi

echo "────────────────────────────"
if [ "$WARN" = 0 ]; then
  echo "✅  Среда готова. Дальше — контекст задач дня (скилл /start)."
else
  echo "⚠️   Есть замечания выше — глянь перед стартом."
fi
exit 0
