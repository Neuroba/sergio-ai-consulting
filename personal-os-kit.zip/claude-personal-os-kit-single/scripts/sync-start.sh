#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────
# sync-start — запускай ПЕРЕД началом работы (Mac/Linux)
# Подтягивает бэкап из GitHub (если правил с веба/телефона), чтобы не работать на старом.
#
# Портативно: корень репозитория вычисляется от расположения скрипта
# (скрипт лежит в <репо>/scripts/). Ветку можно переопределить: BRANCH=master
# ─────────────────────────────────────────────────────────────
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BRANCH="${BRANCH:-main}"
cd "$ROOT"

# Буфер для больших push (один раз, идемпотентно)
git config http.postBuffer 524288000 >/dev/null 2>&1 || true

echo "🔄  Тяну бэкап с GitHub…"
git fetch origin

if git pull --rebase --autostash origin "$BRANCH"; then
  echo ""
  echo "✅  Актуально. Можно работать."
  echo "── последние изменения ──"
  git log --oneline -3
else
  echo ""
  echo "⚠️   Конфликт при обновлении — тот же файл правился с веба/телефона."
  echo "    1) открой файлы с <<<<<<< , оставь нужное"
  echo "    2) git add <файл>"
  echo "    3) git rebase --continue"
  exit 1
fi
