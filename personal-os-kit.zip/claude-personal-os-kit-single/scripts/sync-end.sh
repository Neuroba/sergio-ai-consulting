#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────
# sync-end — запускай ПОСЛЕ работы (Mac/Linux)
# Сохраняет изменения, подтягивает удалённые (rebase), пушит на GitHub.
# Можно передать своё сообщение:  ./sync-end.sh "правил финмодель Проекта A"
#
# Портативно: корень — от расположения скрипта. Ветка: BRANCH=master ./sync-end.sh
# ─────────────────────────────────────────────────────────────
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BRANCH="${BRANCH:-main}"
cd "$ROOT"

git config http.postBuffer 524288000 >/dev/null 2>&1 || true

MSG="${1:-backup: $(date '+%Y-%m-%d %H:%M')}"

echo "💾  Сохраняю изменения…"
git add -A
if git diff --cached --quiet; then
  echo "ℹ️   Локальных изменений нет."
else
  git commit -q -m "$MSG"
  echo "✅  Закоммичено: $MSG"
fi

echo "🔄  Подтягиваю удалённое (rebase)…"
if ! git pull --rebase --autostash origin "$BRANCH"; then
  echo ""
  echo "⚠️   Конфликт. Разреши файлы с <<<<<<< , затем:"
  echo "    git add <файл> && git rebase --continue && git push"
  exit 1
fi

echo "⬆️   Пушу на GitHub…"
git push origin "$BRANCH"
echo ""
echo "✅  Готово. Бэкап сохранён на GitHub."
