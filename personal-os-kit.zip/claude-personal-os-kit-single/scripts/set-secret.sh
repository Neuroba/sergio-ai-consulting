#!/bin/bash
# ─────────────────────────────────────────────────────────────
# set-secret.sh — безопасный ввод токена (macOS)
# Открывает нативный диалог с маскировкой. Токен сохраняется в
# ~/.claude-secrets (НЕ в git, НЕ в чат Claude). Права файла — 600.
# Читать в скриптах:  source ~/.claude-secrets   → $КЛЮЧ
# ─────────────────────────────────────────────────────────────
ENV_FILE="${SECRETS_FILE:-$HOME/.claude-secrets}"

# Имя переменной
KEY=$(osascript -e '
  tell application "System Events"
    set keyName to text returned of (display dialog "Имя переменной (например: TODO_TOKEN)" default answer "" with title "🔐 Секретный ввод — Claude" buttons {"Отмена", "Далее"} default button "Далее")
  end tell
  return keyName
' 2>/dev/null)
[ -z "$KEY" ] && exit 0

# Значение (замаскировано)
VALUE=$(osascript -e '
  tell application "System Events"
    set tokenValue to text returned of (display dialog "Значение для '"$KEY"':" default answer "" with title "🔐 Секретный ввод — Claude" with hidden answer buttons {"Отмена", "Сохранить"} default button "Сохранить")
  end tell
  return tokenValue
' 2>/dev/null)
[ -z "$VALUE" ] && exit 0

touch "$ENV_FILE"
chmod 600 "$ENV_FILE"

# Заменяем старую строку с этим ключом на новую
grep -v "^${KEY}=" "$ENV_FILE" > "${ENV_FILE}.tmp" 2>/dev/null && mv "${ENV_FILE}.tmp" "$ENV_FILE"
echo "${KEY}=${VALUE}" >> "$ENV_FILE"

osascript -e "display notification \"${KEY} сохранён в ${ENV_FILE}\" with title \"✅ Готово\"" 2>/dev/null
echo "✅ ${KEY} сохранён в ${ENV_FILE}"
