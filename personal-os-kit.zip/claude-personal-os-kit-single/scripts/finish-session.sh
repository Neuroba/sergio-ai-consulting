#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────
# finish-session.sh — МЕХАНИКА завершения сессии (без Claude)
# Сохраняет и пушит бэкап в GitHub, проверяет что ничего не потеряно.
# Отчёт о сессии и обновление памяти делает скилл /finish поверх этого.
#
# Использование:  finish-session.sh ["сообщение коммита"]
# ─────────────────────────────────────────────────────────────
set -uo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BRANCH="${BRANCH:-main}"
SECRETS_FILE="${SECRETS_FILE:-$HOME/.claude-secrets}"
MSG="${1:-finish: конец сессии}"
FAIL=0

echo "🏁  ЗАВЕРШЕНИЕ СЕССИИ"
echo "────────────────────────────"

# ① Проекты → GitHub (бэкап)
echo "①  Сохраняю проекты…"
if "$ROOT/scripts/sync-end.sh" "$MSG" >/tmp/finish-sync.log 2>&1; then
  echo "    ✓ проекты запушены"
else
  echo "    ⚠ sync-end: проблема (см. /tmp/finish-sync.log)"; FAIL=1
fi

# ② Проверка что бэкап загружен
echo "②  Проверка бэкапа…"
cd "$ROOT"; git fetch origin -q 2>/dev/null
LOCAL=$(git rev-parse --short HEAD 2>/dev/null)
ORIGIN=$(git rev-parse --short "origin/$BRANCH" 2>/dev/null)
echo "    локально=$LOCAL   origin=$ORIGIN"
if [ "$LOCAL" = "$ORIGIN" ]; then echo "    ✓ локально = origin (бэкап загружен)"; else echo "    ⚠ расхождение с origin!"; FAIL=1; fi

# ③ Секреты на месте
echo "③  Секреты…"
if [ -f "$SECRETS_FILE" ]; then
  MK=$(grep -c '^[A-Za-z_].*=' "$SECRETS_FILE" 2>/dev/null || echo 0)
  echo "    ✓ $MK ключей в $SECRETS_FILE"
else
  echo "    ⚠ нет файла секретов"
fi

echo "────────────────────────────"
if [ "$FAIL" = 0 ]; then
  echo "✅  Всё загружено, бэкап сохранён. Можно закрывать."
else
  echo "⚠️   Есть предупреждения выше — разберись перед закрытием."
fi
exit $FAIL
